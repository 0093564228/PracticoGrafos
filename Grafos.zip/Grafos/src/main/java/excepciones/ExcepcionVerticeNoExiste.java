package excepciones;

public class ExcepcionVerticeNoExiste extends Exception {
    public ExcepcionVerticeNoExiste() {
        super();
    }
    public ExcepcionVerticeNoExiste(String message) {
        super(message);
    }

}
