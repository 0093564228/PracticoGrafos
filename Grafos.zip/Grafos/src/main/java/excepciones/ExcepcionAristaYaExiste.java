package excepciones;

public class ExcepcionAristaYaExiste extends Exception{
    public ExcepcionAristaYaExiste() {
        super();
    }

    public ExcepcionAristaYaExiste(String message) {
        super(message);
    }
}
