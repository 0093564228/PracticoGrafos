package excepciones;

public class ExcepcionVerticeYaExiste extends Exception{
    public ExcepcionVerticeYaExiste() {
        super();
    }

    public ExcepcionVerticeYaExiste(String message) {
        super(message);
    }
}
