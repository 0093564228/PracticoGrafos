package excepciones;

public class ExcepcionAristaNoExiste extends Exception {
    public ExcepcionAristaNoExiste() {
        super();
    }
    public ExcepcionAristaNoExiste(String message) {
        super(message);
    }

}
