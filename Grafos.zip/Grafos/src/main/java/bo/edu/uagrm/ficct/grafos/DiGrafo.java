package bo.edu.uagrm.ficct.grafos;

import excepciones.ExcepcionAristaNoExiste;
import excepciones.ExcepcionAristaYaExiste;
import excepciones.ExcepcionVerticeNoExiste;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class DiGrafo<T extends Comparable<T>>extends Grafo<T>{
    public DiGrafo() {
        super();
    }
    @Override
    public void insertarArista(T verticeOrigen, T verticeDestino) throws ExcepcionAristaYaExiste, ExcepcionVerticeNoExiste {
        if (!this.existeVertice(verticeOrigen)) {
            throw new ExcepcionVerticeNoExiste("Vertice origen no existe");
        }
        if (!this.existeVertice(verticeDestino)) {
            throw new ExcepcionVerticeNoExiste("Vertice origen no existe");
        }
        if (this.existeAdyacencia(verticeOrigen, verticeDestino)) {
            throw new ExcepcionAristaYaExiste("La arista ya existe");
        }
        int posicionVerticeOrigen = this.posicionDeVertice(verticeOrigen);
        int posicionVerticeDestino = this.posicionDeVertice(verticeDestino);
        List<Integer> adyacentesAlOrigen = this.listaDeAdyacencia.get(posicionVerticeOrigen);
        adyacentesAlOrigen.add(posicionVerticeDestino);
        Collections.sort(adyacentesAlOrigen);

    }

    @Override
    public
    int cantidadDeAristas() {
        return super.cantidadDeAristas();//terminar
    }

    @Override
    public void eliminarArista(T verticeOrigen, T verticeDestino) throws ExcepcionAristaNoExiste, ExcepcionVerticeNoExiste {
        super.eliminarArista(verticeOrigen, verticeDestino);//terminar
    }

    @Override
    public int gradoDe(T vertice) throws ExcepcionVerticeNoExiste {
        throw new UnsupportedOperationException("No soportado en grafos dirigidos");
    }

    public int gradoDeEntrada(T unVertice) throws ExcepcionVerticeNoExiste {
        return 0 ;//terminar
    }

    public int gradoDeSalida(T unVertice) throws ExcepcionVerticeNoExiste {
        return super.gradoDe(unVertice);
    }

    @Override
    public boolean esConexo() {
        throw new UnsupportedOperationException("No soportado en grafos dirigidos");
    }
    public boolean esFuertementoConexo() {
        List<T> elRecorrido;
        for (T unVertice: this.listaDeVertices) {
            elRecorrido = this.dfs(unVertice);
            if (elRecorrido.size() != this.cantidadDeVertices()) {
                return false;
            }
        }
        return true;
    }
    public boolean esDevilmenteConexo() {
        List<T> recorrido = new ArrayList<T>();
        List<Boolean> marcados = inicializaMarcados();
        int posicionDeVerticeInicial = 0;
        do {
            dfs(recorrido, marcados, posicionDeVerticeInicial);
            if (estanTodosMarcados(marcados)) {
                return true;
            }
            posicionDeVerticeInicial = posicionVerticeNoMarcadoConAdyacenteMarcado(marcados);
        }while(!estanTodosMarcados(marcados) && posicionDeVerticeInicial!= POSICION_INVALIDA);
        return false;
    }

    private int posicionVerticeNoMarcadoConAdyacenteMarcado(List<Boolean> marcados) {

        for (int i = 0; i < marcados.size(); i++) {
            if (!this.estaMarcadoElVertice(marcados,i) ) {
                if (this.existeAdyacenteMarcado(marcados, this.listaDeAdyacencia.get(i))) {
                    return i;
                }
            }
        }
        return POSICION_INVALIDA;
    }

    private boolean existeAdyacenteMarcado(List<Boolean> marcados, List<Integer> adyacenciasAlVertice) {
        for (Integer adyacentesDelVertice : adyacenciasAlVertice) {
            if (this.estaMarcadoElVertice(marcados,adyacentesDelVertice)) {
                return true;
            }
        }
        return false;
    }


    @Override
    public int cantidadDeIslas() {
        List<T> recorrido = new LinkedList<T>();
        int posicionDeVerticeInicial = 0;
        int contadorDeIslas = 0;
        List<Boolean> marcados = inicializaMarcados();
        while (!this.estanTodosMarcados(marcados) && posicionDeVerticeInicial != POSICION_INVALIDA) {
            while (!this.estanTodosMarcados(marcados) && posicionDeVerticeInicial != POSICION_INVALIDA) {
                dfs(recorrido, marcados, posicionDeVerticeInicial);
                posicionDeVerticeInicial = posicionVerticeNoMarcadoConAdyacenteMarcado(marcados);
            }
            contadorDeIslas = contadorDeIslas + 1;
            posicionDeVerticeInicial = posicionDeVerticeNoMarcado(marcados);
        }
        return contadorDeIslas;
    }

    @Override
    public boolean hayCiclo()  {
        List<Boolean> marcados = this.inicializaMarcados();
        int posicionVerticeInicial = 0;
        do {

            do {
                boolean hayCiclo = dfsHayCiclo(marcados, posicionVerticeInicial);
                if (hayCiclo) {
                    return true;
                }
                posicionVerticeInicial = posicionVerticeNoMarcadoConAdyacenteMarcado(marcados);
            }while (posicionVerticeInicial != POSICION_INVALIDA);

            posicionVerticeInicial = posicionDeVerticeNoMarcado(marcados);
        }while (posicionVerticeInicial != POSICION_INVALIDA);

        return true;
    }

    protected boolean dfsHayCiclo(List<Boolean> marcados, int posicionEnTurno ) {
        marcarVertice(marcados, posicionEnTurno);
        List<Integer> adyacentesAlVertice = this.listaDeAdyacencia.get(posicionEnTurno);
        for(Integer posicionDeAdyacente : adyacentesAlVertice) {
            if (!this.estaMarcadoElVertice(marcados, posicionDeAdyacente)) {
                dfsHayCiclo(marcados, posicionDeAdyacente);
            }else{
                return true;
            }
        }
        return false;
    }
}
