package bo.edu.uagrm.ficct.grafos;

public class GrafoPesado {

}
