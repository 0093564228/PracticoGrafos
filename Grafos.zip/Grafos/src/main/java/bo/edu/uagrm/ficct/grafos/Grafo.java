package bo.edu.uagrm.ficct.grafos;
import excepciones.ExcepcionAristaNoExiste;
import excepciones.ExcepcionAristaYaExiste;
import excepciones.ExcepcionVerticeNoExiste;
import excepciones.ExcepcionVerticeYaExiste;

import java.util.ArrayList;
import java.util.*;
public class Grafo<T extends Comparable<T>> {
    protected List<T> listaDeVertices;
    protected List<List<Integer>> listaDeAdyacencia;
    protected static final int POSICION_INVALIDA = -1;

    public Grafo() {
        this.listaDeVertices = new ArrayList<T>();
        this.listaDeAdyacencia = new ArrayList<List<Integer>>();
    }

    public void insertarVertice(T vertice) throws ExcepcionVerticeYaExiste {
        if (this.existeVertice(vertice)) {
            throw new ExcepcionVerticeYaExiste();
        }
        this.listaDeVertices.add(vertice);
        List<Integer> listaDeAdyacentesDelVertice = new ArrayList<Integer>();
        this.listaDeAdyacencia.add(listaDeAdyacentesDelVertice);
    }

    public boolean existeVertice(T vertice) {
        //this.listaDeVertices.contains(vertice);
        return this.posicionDeVertice(vertice) != POSICION_INVALIDA;
    }

    protected int posicionDeVertice(T vertice) {
        for (int i = 0; i < listaDeVertices.size(); i++) {
            T verticeEnTurno = this.listaDeVertices.get(i);
            if (verticeEnTurno.compareTo(vertice) == 0) {
                return i;
            }
        }
        return POSICION_INVALIDA;
    }

    public int cantidadDeVertices() {
        return this.listaDeVertices.size();
    }

    public void insertarArista(T verticeOrigen, T verticeDestino) throws ExcepcionAristaYaExiste, ExcepcionVerticeNoExiste {
        if (!this.existeVertice(verticeOrigen)) {
            throw new ExcepcionVerticeNoExiste("Vertice origen no existe");
        }
        if (!this.existeVertice(verticeDestino)) {
            throw new ExcepcionVerticeNoExiste("Vertice destino no existe");
        }
        if (this.existeAdyacencia(verticeOrigen, verticeDestino)) {
            throw new ExcepcionAristaYaExiste("La arista ya existe");
        }
        int posicionVerticeOrigen = this.posicionDeVertice(verticeOrigen);
        int posicionVerticeDestino = this.posicionDeVertice(verticeDestino);
        List<Integer> adyacentesAlOrigen = this.listaDeAdyacencia.get(posicionVerticeOrigen);
        adyacentesAlOrigen.add(posicionVerticeDestino);
        Collections.sort(adyacentesAlOrigen);

        if (posicionVerticeDestino != posicionVerticeOrigen) {
            List<Integer> adyacentesAlDestino = this.listaDeAdyacencia.get(posicionVerticeDestino);
            adyacentesAlDestino.add(posicionVerticeOrigen);
            Collections.sort(adyacentesAlDestino);
        }
    }

    /**
     * Retorna verdadero si existe la adyacencia.
     * Pre-condicion: Los vertices ya existen en el grafo.
     *
     * @param verticeOrigen
     * @param verticeDestino
     * @return
     */
    public boolean existeAdyacencia(T verticeOrigen, T verticeDestino) {
        int posicionVerticeOrigen = this.posicionDeVertice(verticeOrigen);
        int posicionVerticeDestino = this.posicionDeVertice(verticeDestino);
        List<Integer> adyacentesAlOrigen = this.listaDeAdyacencia.get(posicionVerticeOrigen);

        return adyacentesAlOrigen.contains(posicionVerticeDestino);
    }

    public int cantidadDeAristas() {
        List<Integer> listaAuxiliar = new LinkedList<Integer>();
        int cantidadDeAristas = 0;
        for (int i = 0; i < this.listaDeVertices.size() ; i++) {
            List<Integer> listaDeAdyacenciaActual = this.listaDeAdyacencia.get(i);
            for (int j = 0; j < listaDeAdyacenciaActual.size() ; j++) {
                int posicionDeAdyacente = listaDeAdyacenciaActual.get(j);
                if (!listaAuxiliar.contains(posicionDeAdyacente)){
                    cantidadDeAristas = cantidadDeAristas + 1;
                }
            }
            listaAuxiliar.add(i);
        }
        return cantidadDeAristas;
    }

    public void eliminarVertice(T verticeAEliminar) throws ExcepcionVerticeNoExiste {
        if (!this.existeVertice(verticeAEliminar)) {
            throw new ExcepcionVerticeNoExiste("Vertice a eliminar no existe en el grafo");
        }
        int posicionDelVerticeAEliminar = this.posicionDeVertice(verticeAEliminar);
        this.listaDeVertices.remove(posicionDelVerticeAEliminar);
        this.listaDeAdyacencia.remove(posicionDelVerticeAEliminar);

        for (List<Integer> adyacentesDeUnVertice : this.listaDeAdyacencia) {
            if (adyacentesDeUnVertice.contains(posicionDelVerticeAEliminar)) {
                int posicionDelVerticeComoAdyacente = adyacentesDeUnVertice.indexOf(posicionDelVerticeAEliminar);
                adyacentesDeUnVertice.remove(posicionDelVerticeComoAdyacente);
            }
            for (int i = 0; i < adyacentesDeUnVertice.size(); i++) {
                int posicionDeAdyacente = adyacentesDeUnVertice.get(i);
                if (posicionDeAdyacente > posicionDelVerticeAEliminar) {
                    posicionDeAdyacente--;
                    adyacentesDeUnVertice.set(i, posicionDeAdyacente);
                }
            }
        }
    }

    public void eliminarArista(T verticeOrigen, T verticeDestino) throws ExcepcionAristaNoExiste, ExcepcionVerticeNoExiste {
        if (!existeVertice(verticeOrigen)) {
            throw new ExcepcionVerticeNoExiste ("El vertice origen no existe");
        }

        if (!existeVertice(verticeDestino)) {
            throw new ExcepcionVerticeNoExiste ("El vertice destino no existe");
        }

        if (!existeAdyacencia(verticeOrigen, verticeDestino)) {
            throw new ExcepcionAristaNoExiste("La arista no existe");
        }
        int posicionVerticeOrigen = posicionDeVertice(verticeOrigen);
        int posicionVerticeDestino = posicionDeVertice(verticeDestino);
        List<Integer> adyacentesAlOrigen = this.listaDeAdyacencia.get(posicionVerticeOrigen);
        int posicionDelVerticeComoAdyacente1 = adyacentesAlOrigen.indexOf(posicionVerticeDestino);
        adyacentesAlOrigen.remove(posicionDelVerticeComoAdyacente1);

        if (posicionVerticeDestino != posicionVerticeOrigen) {
            List<Integer> adyacentesAlDestino = this.listaDeAdyacencia.get(posicionVerticeDestino);
            int posicionDelVerticeComoAdyacente2 = adyacentesAlDestino.indexOf(posicionVerticeOrigen);
            adyacentesAlDestino.remove(posicionDelVerticeComoAdyacente2);
        }
    }

    public int gradoDe(T vertice) throws ExcepcionVerticeNoExiste {
        if (!this.existeVertice(vertice)) {
            throw new ExcepcionVerticeNoExiste("Vertice no existe");
        }
        int posicionDeVertive = this.posicionDeVertice(vertice);
        List<Integer> adyacentesDelVertice = this.listaDeAdyacencia.get(posicionDeVertive);
        return adyacentesDelVertice.size();
    }

    public List<T> bfs(T verticeInicial) {
        List<T> recorrido = new ArrayList<T>();
        if (!this.existeVertice(verticeInicial)) {
            return recorrido;
        }
        List<Boolean> marcados = inicializaMarcados();
        Queue<T> colaDeVertices = new LinkedList<T>();
        colaDeVertices.offer(verticeInicial);
        int posicionDeVerticeInicial = posicionDeVertice(verticeInicial);
        marcarVertice(marcados, posicionDeVerticeInicial);
        do {
            T verticeEnTurno = colaDeVertices.poll();
            recorrido.add(verticeEnTurno);
            int posicionDeVerticeEnTurno = posicionDeVertice(verticeEnTurno);
            List<Integer> adyacenciasDeVerticeEnTurno = this.listaDeAdyacencia.get(posicionDeVerticeEnTurno);
            for (Integer posicionDeAdyacente : adyacenciasDeVerticeEnTurno) {
                if (!estaMarcadoElVertice(marcados, posicionDeAdyacente)) {
                    colaDeVertices.offer(this.listaDeVertices.get(posicionDeAdyacente));
                    marcarVertice(marcados, posicionDeAdyacente);
                }
            }
        } while (!colaDeVertices.isEmpty());

        return recorrido;
    }

    protected boolean estaMarcadoElVertice(List<Boolean> marcados, int posicion) {
        return marcados.get(posicion);

    }

    protected void marcarVertice(List<Boolean> marcados, int posicionDeVerticeInicial) {
        marcados.set(posicionDeVerticeInicial, Boolean.TRUE);
    }

    protected List<Boolean> inicializaMarcados() {
        List<Boolean> marcados = new ArrayList<Boolean>();
        for (int i = 0; i < this.cantidadDeVertices(); i++) {
            marcados.add(Boolean.FALSE);
        }
        return marcados;
    }

    public List<T> dfs(T verticeInicial) {
        List<T> recorrido = new ArrayList<T>();
        if (!this.existeVertice(verticeInicial)) {
            return recorrido;
        }
        List<Boolean> marcados = inicializaMarcados();
        int posicionDeVerticInicial = this.posicionDeVertice(verticeInicial);
        dfs(recorrido, marcados, posicionDeVerticInicial);
        return recorrido;
    }

    protected void dfs(List<T> recorrido, List<Boolean> marcados, int posicionEnTurno) {
        marcarVertice(marcados, posicionEnTurno);
        recorrido.add(this.listaDeVertices.get(posicionEnTurno));
        List<Integer> adyacenciasDeVerticeEnTurno = this.listaDeAdyacencia.get(posicionEnTurno);
        for (Integer posicionDeAdyacente : adyacenciasDeVerticeEnTurno) {
            if (!estaMarcadoElVertice(marcados, posicionDeAdyacente)) {
                dfs(recorrido, marcados, posicionDeAdyacente);
            }
        }
    }

    public boolean esConexo() {
        List<T> elRecorrido = bfs(this.listaDeVertices.get(0));
        return elRecorrido.size() == this.cantidadDeVertices();
    }


    @Override
    public String toString() {

        return "Grafo{" +
                "listaDeVertices=" + listaDeVertices +
                ", listaDeAdyacencia=" + listaDeAdyacencia +
                '}';
    }
    public String toString1(int i) {
        return "{" +
                "Vertice " + i + " =  " + listaDeVertices.get(i) +
                ", listaDeAdyacencia = " + listaDeAdyacencia.get(i) +
                '}';

    }
    public int cantidadDeIslas() {
        int posicionDeVerticeInicial = 0;
        int contadorDeIslas = 1;
        List<T> recorrido = new LinkedList<T>();
        List<Boolean> marcados = inicializaMarcados();

        while (!estanTodosMarcados(marcados) && posicionDeVerticeInicial != POSICION_INVALIDA) {
            dfs(recorrido,marcados,posicionDeVerticeInicial);
            if (estanTodosMarcados(marcados)) {
                return contadorDeIslas;
            }
            posicionDeVerticeInicial = posicionDeVerticeNoMarcado(marcados);
            contadorDeIslas = contadorDeIslas + 1;
        }
        return contadorDeIslas;
    }

    protected int posicionDeVerticeNoMarcado(List<Boolean> marcados){
        for(int i = 0; i < this.cantidadDeVertices(); i++) {
            if (!this.estaMarcadoElVertice(marcados, i)) {
                return i;
            }
        }
        return POSICION_INVALIDA;
    }

    protected boolean estanTodosMarcados(List<Boolean> marcados) {
        for (int i = 0; i < this.cantidadDeVertices(); i++) {
            if (!marcados.get(i)) {
                return false;
            }
        }
        return true;
    }
     public boolean hayCiclo() throws ExcepcionAristaYaExiste, ExcepcionVerticeNoExiste {
        Grafo<T> grafo = new Grafo<T>();
        Grafo<T> grafoAuxiliar = this.iniciliazaGrafo(grafo);
        List<Boolean> marcados = inicializaMarcados();
        int posicionDeVerticeInicial = 0;
        do {
            Boolean existeCiclo = dfs2(posicionDeVerticeInicial, grafoAuxiliar, marcados);

            if (existeCiclo) {
                return true;
            } else {
                if (this.estanTodosMarcados(marcados)) {
                    return false;
                }
                posicionDeVerticeInicial = this.posicionDeVerticeNoMarcado(marcados);
            }
        }while (posicionDeVerticeInicial != POSICION_INVALIDA);
        return false;
     }
    protected Boolean dfs2(int posicionEnTurno, Grafo grafoAuxliar, List<Boolean> marcados) throws ExcepcionAristaYaExiste, ExcepcionVerticeNoExiste {
        marcarVertice(marcados, posicionEnTurno);
        List<Integer> adyacenciasDeVerticeEnTurno = this.listaDeAdyacencia.get(posicionEnTurno);
        for (Integer posicionDeAdyacente : adyacenciasDeVerticeEnTurno) {
            if (!this.estaMarcadoElVertice(marcados, posicionDeAdyacente)) {
                this.añadirAristaAGrafoAuxliar(grafoAuxliar, posicionEnTurno, posicionDeAdyacente);
                dfs2(posicionDeAdyacente,grafoAuxliar, marcados);
            }
            if (!this.existeAristaEnELGrafo(grafoAuxliar, posicionEnTurno, posicionDeAdyacente)) {
                return true;
            }
        }
        return false;
    }

    protected Boolean existeAristaEnELGrafo(Grafo grafoAuxliar, int posicionEnturno, int posicionAdyacente) {
        List<Integer> listaDeAdyacencia = (List<Integer>)grafoAuxliar.listaDeAdyacencia.get(posicionEnturno);
        return listaDeAdyacencia.contains(posicionAdyacente);
    }

    private void añadirAristaAGrafoAuxliar(Grafo grafoAuxliar, int posicionEnTurno, Integer posicionDeAdyacente) throws ExcepcionAristaYaExiste, ExcepcionVerticeNoExiste {
        grafoAuxliar.insertarArista(listaDeVertices.get(posicionEnTurno), listaDeVertices.get(posicionDeAdyacente));
    }


    protected Grafo iniciliazaGrafo(Grafo grafoAuxiliar) {

         for (int i = 0; i < this.cantidadDeVertices(); i++) {
             grafoAuxiliar.listaDeVertices.add(i, listaDeVertices.get(i));
             List<Integer> listaDeAdyacencia = new LinkedList<Integer>();
             grafoAuxiliar.listaDeAdyacencia.add(i,listaDeAdyacencia);
         }
        return grafoAuxiliar;
     }


}
