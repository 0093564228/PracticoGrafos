package ui;

import bo.edu.uagrm.ficct.grafos.DiGrafo;
import bo.edu.uagrm.ficct.grafos.Grafo;
import excepciones.ExcepcionAristaNoExiste;
import excepciones.ExcepcionAristaYaExiste;
import excepciones.ExcepcionVerticeNoExiste;
import excepciones.ExcepcionVerticeYaExiste;

import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Test<T extends Comparable<T>> extends Grafo<T> {

    public static void main(String args[]) throws ExcepcionVerticeNoExiste, ExcepcionVerticeYaExiste, ExcepcionAristaYaExiste, ExcepcionAristaNoExiste {
        Grafo grafoDePrueba = new Grafo();

        grafoDePrueba.insertarVertice('A');
        grafoDePrueba.insertarVertice('B');
        grafoDePrueba.insertarVertice('C');
        grafoDePrueba.insertarVertice('D');
        grafoDePrueba.insertarVertice('E');
        grafoDePrueba.insertarVertice('F');
        grafoDePrueba.insertarVertice('G');
        grafoDePrueba.insertarVertice('H');
        grafoDePrueba.insertarVertice('I');
        grafoDePrueba.insertarVertice('K');

        grafoDePrueba.insertarArista('A', 'B');
        grafoDePrueba.insertarArista('A', 'C');
        grafoDePrueba.insertarArista('A', 'G');

        grafoDePrueba.insertarArista('B', 'D');
        grafoDePrueba.insertarArista('B', 'E');

        grafoDePrueba.insertarArista('C', 'E');

        grafoDePrueba.insertarArista('D', 'E');
        grafoDePrueba.insertarArista('D', 'F');

        grafoDePrueba.insertarArista('E', 'G');

        grafoDePrueba.insertarArista('F', 'G');
        grafoDePrueba.insertarArista('F', 'I');

        grafoDePrueba.insertarArista('G', 'H');
        grafoDePrueba.insertarArista('G', 'K');
        grafoDePrueba.insertarArista('G', 'I');

        System.out.println("Grafo no dirigido");
        for (int i = 0; i < grafoDePrueba.cantidadDeVertices(); i++) {
            System.out.println(grafoDePrueba.toString1(i));
        }


        //--------------------------------------DIGRAFO------------------------------------------------------------------------
        DiGrafo digrafoDePrueba = new DiGrafo();
        digrafoDePrueba.insertarVertice('A');
        digrafoDePrueba.insertarVertice('B');
        digrafoDePrueba.insertarVertice('C');
        digrafoDePrueba.insertarVertice('D');
        digrafoDePrueba.insertarVertice('E');
        digrafoDePrueba.insertarVertice('F');
        digrafoDePrueba.insertarVertice('G');
        digrafoDePrueba.insertarVertice('H');
        digrafoDePrueba.insertarVertice('I');
        digrafoDePrueba.insertarVertice('K');

        digrafoDePrueba.insertarArista('A', 'B');
        digrafoDePrueba.insertarArista('A', 'C');
        digrafoDePrueba.insertarArista('A', 'G');

        digrafoDePrueba.insertarArista('B', 'D');

        digrafoDePrueba.insertarArista('C', 'E');

        digrafoDePrueba.insertarArista('D', 'E');

        digrafoDePrueba.insertarArista('E', 'B');

        digrafoDePrueba.insertarArista('F', 'D');
        digrafoDePrueba.insertarArista('F', 'G');

        digrafoDePrueba.insertarArista('G', 'E');
        digrafoDePrueba.insertarArista('G', 'H');
        digrafoDePrueba.insertarArista('G', 'I');

        digrafoDePrueba.insertarArista('I', 'F');

        digrafoDePrueba.insertarArista('K', 'G');

        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("grafo dirigido");
        for (int i = 0; i < digrafoDePrueba.cantidadDeVertices(); i++) {
            System.out.println(digrafoDePrueba.toString1(i));
        }
        System.out.println("-------------------------------------------------------------------------------------");

        System.out.println("1. En un grafo dirigido implementar un algoritmo para encontrar si el grafo tiene ciclos");
        System.out.println("Respuesta para digrafoAuxiliar: " + digrafoDePrueba.hayCiclo());

        System.out.println("2. En un grafo dirigido implementar un algoritmo para encontrar si es débilmente conexo");
        System.out.println("Respuesta para digrafoAuxiliar: " + digrafoDePrueba.esDevilmenteConexo());

        System.out.println("3. En un grafo no dirigido implementar un algoritmo para encontrar si el grafo tiene ciclo");
        System.out.println("Respuesta para grafoAxuliar: " + grafoDePrueba.hayCiclo());

        System.out.println("4. En un grafo no dirigido implementar un algoritmo para encontrar el número de islas que hay en el grafo");
        System.out.println("Respuesta para grafoAxuliar: " + grafoDePrueba.cantidadDeIslas());

        System.out.println("5. En un grafo dirigido implementar un algoritmo para encontrar el número de islas que hay en el grafo");
        System.out.println("Respuesta para digrafoAuxiliar: " + digrafoDePrueba.cantidadDeIslas());
    }
}
